package Characters;

public class Mage extends Player {
    public Mage(String name) {
        super(name, 80, 15, 5, 60, 20); // maxMana=60, coste especial=20
    }

    @Override
    public void special(Character target) {
        spendMana(); // CORRECCIÓN: Gasta maná
        System.out.println(getName() + " lanza Bola de Fuego!");
        target.takeDamage(getAttack() + 20);
    }
}