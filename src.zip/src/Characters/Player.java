package Characters;

public abstract class Player extends Character {
    private int level;
    private int exp;
    private int mana;
    private int maxMana;
    private final int specialManaCost;

    public Player(String name, int hp, int attack, int defense,
                  int maxMana, int specialManaCost) {
        super(name, hp, attack, defense);
        this.level = 1;
        this.exp = 0;
        this.maxMana = maxMana;
        this.mana = maxMana;
        this.specialManaCost = specialManaCost;
    }

    // =========================================================
    //  GETTERS — necesarios para que Game.java pueda leerlos
    // =========================================================

    public int getLevel()           { return level; }
    public int getExp()             { return exp; }
    public int getMana()            { return mana; }
    public int getMaxMana()         { return maxMana; }
    public int getSpecialManaCost() { return specialManaCost; }

    // =========================================================
    //  ATAQUE BASE
    // =========================================================

    @Override
    public int attack() {
        // getAttack() viene de Character (ahora private allí, acceso por getter)
        return getAttack() + (level * 2);
    }

    // =========================================================
    //  SISTEMA DE MANÁ
    // =========================================================

    public boolean canUseSpecial() {
        return mana >= specialManaCost;
    }

    protected void spendMana() {
        if (!canUseSpecial()) {
            System.out.println("¡Maná insuficiente! Necesitas " + specialManaCost
                    + " y tienes " + mana + ".");
            throw new IllegalStateException("Maná insuficiente");
        }
        mana -= specialManaCost;
    }

    public void regenMana(int amount) {
        mana = Math.min(mana + amount, maxMana);
    }

    // =========================================================
    //  SISTEMA DE EXPERIENCIA Y NIVEL
    // =========================================================

    public void gainExp(int amount) {
        exp += amount;
        System.out.printf("%s gana %d EXP. (Total: %d/100)%n", getName(), amount, exp);
        if (exp >= 100) {
            level++;
            exp -= 100; // conservar el exceso, no perderlo
            setMaxHp(getMaxHp() + 20);
            setHp(getMaxHp());        // curación completa al subir nivel
            setAttack(getAttack() + 3);
            setDefense(getDefense() + 2);
            maxMana += 10;
            mana = maxMana;
            System.out.printf(">>> ¡%s sube a NIVEL %d! Stats mejorados. <<<\n",
                    getName(), level);
        }
    }
}