// Characters/factory/EnemyFactory.java
package Characters.factory;

import Characters.Enemy;

public class EnemyFactory {

    public enum EnemyType { GOBLIN, ORC, DRAGON }

    public static Enemy create(EnemyType type) {
        return switch (type) {
            case GOBLIN -> new Enemy("Goblin",  40,  10,  3);
            case ORC    -> new Enemy("Orco",    80,  18,  8);
            case DRAGON -> new Enemy("Dragón", 200,  35, 15);
        };
    }

    // Sobrecarga útil: crear un enemigo aleatorio para el mapa
    public static Enemy createRandom() {
        EnemyType[] types = EnemyType.values();
        EnemyType random = types[(int)(Math.random() * types.length)];
        return create(random);
    }
}