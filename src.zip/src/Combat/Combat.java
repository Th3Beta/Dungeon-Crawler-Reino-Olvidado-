package Combat;

import Characters.Player;
import Characters.Enemy;
import java.util.Scanner;

public class Combat {
    public static void fight(Player player, Enemy enemy, Scanner sc) {
        // CORRECCIÓN: Eliminada la línea "Scanner sc = new Scanner(System.in);"
        System.out.println("¡Combate contra " + enemy.getName() + "!");

        while (player.isAlive() && enemy.isAlive()) {
            System.out.println("Elige acción: 1-Atacar 2-Especial");
            int choice = sc.nextInt();

            if (choice == 1) {
                enemy.takeDamage(player.attack());
            } else {
                try {
                    player.special(enemy);
                } catch (IllegalStateException e) {
                    // Si no hay maná, el jugador pierde el turno (o podrías dejar que vuelva a elegir)
                    System.out.println("Ataque fallido por falta de maná.");
                }
            }

            System.out.println("HP enemigo: " + enemy.getHp()); // CORRECCIÓN: getHp()

            if (!enemy.isAlive()) break;

            player.takeDamage(enemy.attack());
            System.out.println("Tu HP: " + player.getHp()); // CORRECCIÓN: getHp()
        }

        if (player.isAlive()) {
            System.out.println("¡Has ganado!");
            player.gainExp(50);
        } else {
            System.out.println("Has muerto...");
        }
    }
}