import Characters.*;
import Characters.factory.PlayerFactory;
import Map.Map;
import Combat.Combat;
import Inventory.Inventory;
import Inventory.Potion;
import Management.Party;

import java.util.Scanner;

public class Game {
    private Party party;
    private Player activePlayer;
    private Map map;
    private Inventory inventory;
    private Scanner sc;

    public Game() {
        sc = new Scanner(System.in);
        inventory = new Inventory(10);
        party = new Party();
        map = new Map(5);

        partyManagementMenu();
    }

    // =========================================================
    //  MENÚ DE GESTIÓN DE GRUPO
    // =========================================================

    private void partyManagementMenu() {
        int option = 0;
        do {
            System.out.println("\n=== GESTIÓN DE GRUPO ===");
            System.out.println("1. Añadir personaje");
            System.out.println("2. Eliminar personaje");
            System.out.println("3. Listar personajes por clase");
            System.out.println("4. Empezar aventura (Requiere al menos 1 personaje)");

            option = readIntInRange(1, 4);

            switch (option) {
                case 1 -> createCharacter();
                case 2 -> {
                    System.out.print("Introduce el nombre del personaje a eliminar: ");
                    String nameToRemove = sc.nextLine();
                    party.removeCharacter(nameToRemove);
                }
                case 3 -> {
                    System.out.print("Introduce la clase a buscar (Warrior, Mage, Archer): ");
                    String typeToSearch = sc.nextLine();
                    party.listCharactersByType(typeToSearch);
                }
                case 4 -> {
                    if (party.isEmpty()) {
                        System.out.println("¡No puedes empezar sin personajes! Añade uno primero.");
                        option = 0; // fuerza continuar el bucle
                    }
                }
            }

        } while (option != 4);

        activePlayer = party.getActivePlayer();
    }

    // =========================================================
    //  CREACIÓN DE PERSONAJE (usa PlayerFactory)
    // =========================================================

    private void createCharacter() {
        System.out.println("\nElige tu clase:");
        System.out.println("  1 - Warrior  (HP: 120 | ATK: 20 | DEF: 10) - Tanque cuerpo a cuerpo");
        System.out.println("  2 - Mage     (HP:  80 | ATK: 15 | DEF:  5) - Daño mágico explosivo");
        System.out.println("  3 - Archer   (HP:  90 | ATK: 18 | DEF:  6) - Equilibrado y veloz");

        int choice = readIntInRange(1, 3);
        String[] types = {"warrior", "mage", "archer"};

        System.out.print("Nombre de tu personaje: ");
        String name = sc.nextLine().trim();
        if (name.isEmpty()) name = "Héroe";

        try {
            Player newPlayer = PlayerFactory.create(types[choice - 1], name);
            party.addCharacter(newPlayer);
        } catch (IllegalArgumentException e) {
            System.out.println("Error al crear personaje: " + e.getMessage());
        }
    }

    // =========================================================
    //  BUCLE PRINCIPAL DE JUEGO
    // =========================================================

    public void start() {
        System.out.println("\n¡Comenzando aventura con " + activePlayer.getName() + "!");

        char option;
        do {
            printHud();
            map.draw();
            System.out.println("Mover (w/a/s/d) | i inventario | q salir");
            option = readChar('w', 'a', 's', 'd', 'i', 'q');

            switch (option) {
                case 'i' -> handleInventory();
                case 'q' -> System.out.println("Abandonando aventura...");
                default  -> handleMovement(option);
            }

        } while (option != 'q' && activePlayer.isAlive());

        if (!activePlayer.isAlive()) {
            System.out.println("\n=== FIN DE LA PARTIDA ===");
            System.out.println(activePlayer.getName() + " ha caído en batalla. Fin del juego.");
        }
    }

    // =========================================================
    //  ACCIONES DEL BUCLE PRINCIPAL
    // =========================================================

    private void handleMovement(char direction) {
        map.movePlayer(direction);
        Enemy enemy = map.checkEnemy();
        if (enemy != null) {
            Combat.fight(activePlayer, enemy, sc);
            if (!enemy.isAlive()) {
                map.removeEnemy();
                // Añade una poción como recompensa tras vencer al enemigo
                inventory.addItem(new Potion("Poción menor", 30));
            }
        }
    }

    private void handleInventory() {
        if (inventory.isEmpty()) {
            System.out.println("El inventario está vacío.");
            return;
        }
        inventory.showItems();
        System.out.print("Usa un ítem (número) o 0 para cancelar: ");
        int choice = readIntInRange(0, inventory.getSize());
        if (choice > 0) {
            inventory.useItem(choice - 1, activePlayer);
        }
    }

    // =========================================================
    //  HUD (cabecera de estado del jugador)
    // =========================================================

    private void printHud() {
        System.out.printf("%n[ %s | Nivel %d | HP: %d/%d | Maná: %d/%d ]%n",
                activePlayer.getName(),
                activePlayer.getLevel(),
                activePlayer.getHp(),
                activePlayer.getMaxHp(),
                activePlayer.getMana(),
                activePlayer.getMaxMana()
        );
    }

    // =========================================================
    //  UTILIDADES DE ENTRADA — Scanner a prueba de fallos
    // =========================================================

    /**
     * Lee un entero dentro del rango [min, max] inclusive.
     * No retorna hasta obtener una entrada válida.
     */
    private int readIntInRange(int min, int max) {
        while (true) {
            System.out.printf("Elige una opción (%d-%d): ", min, max);
            if (sc.hasNextInt()) {
                int value = sc.nextInt();
                sc.nextLine(); // limpiar el \n residual
                if (value >= min && value <= max) {
                    return value;
                }
                System.out.printf("Fuera de rango. Debe ser entre %d y %d.%n", min, max);
            } else {
                System.out.println("Entrada inválida. Por favor, introduce un número.");
                sc.nextLine(); // descartar la línea basura completa
            }
        }
    }

    /**
     * Lee un único carácter que pertenezca al conjunto de opciones válidas.
     * No retorna hasta obtener una entrada válida.
     */
    private char readChar(char... validOptions) {
        while (true) {
            String input = sc.nextLine().trim().toLowerCase();
            if (input.length() == 1) {
                char c = input.charAt(0);
                for (char valid : validOptions) {
                    if (c == valid) return c;
                }
            }
            System.out.print("Opción no válida. Introduce una de [w/a/s/d/i/q]: ");
        }
    }
}