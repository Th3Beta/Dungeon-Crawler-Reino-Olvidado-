package Management;

import Characters.Player;

public interface IPartyManager {
    void addCharacter(Player p);
    void removeCharacter(String name);
    void listCharactersByType(String type);
}