package Map;

import Characters.Enemy;

public class Map {
    private char[][] grid;
    private int playerX;
    private int playerY;
    private Enemy[][] enemies;

    public Map(int size) {
        grid = new char[size][size];
        enemies = new Enemy[size][size];
        playerX = size / 2;
        playerY = size / 2;

        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                grid[i][j] = '.';
                if (Math.random() < 0.2 && !(i==playerX && j==playerY)) {
                    enemies[i][j] = new Enemy("Goblin", 40, 10, 3);
                    grid[i][j] = 'E';
                }
            }
        }
        grid[playerX][playerY] = 'P';
    }

    public void draw() {
        for (int i = 0; i < grid.length; i++) {
            for (int j = 0; j < grid[i].length; j++) {
                System.out.print(grid[i][j] + " ");
            }
            System.out.println();
        }
    }

    public Enemy checkEnemy() {
        return enemies[playerX][playerY];
    }

    public void removeEnemy() {
        enemies[playerX][playerY] = null;
        grid[playerX][playerY] = 'P';
    }

    public void movePlayer(char dir) {
        grid[playerX][playerY] = '.';

        if (dir == 'w' && playerX > 0) playerX--;
        if (dir == 's' && playerX < grid.length - 1) playerX++;
        if (dir == 'a' && playerY > 0) playerY--;
        if (dir == 'd' && playerY < grid[0].length - 1) playerY++;

        grid[playerX][playerY] = 'P';
    }
}